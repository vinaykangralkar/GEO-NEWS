<div id="map">
	   <!--HERE LOADS THE MAP-->
</div>