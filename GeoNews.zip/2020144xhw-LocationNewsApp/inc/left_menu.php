 <div class="col-md-3 left_col">
        <div class="left_col scroll-view">
          <div class="navbar nav_title" style="border: 0;">
            <a href="index.php?lat=<?php echo $_GET['lat'];?>&lon=<?php echo $_GET['lon'];?>" class="site_title"><i class="fa fa-area-chart"></i> <span>MapMyNews</span></a>
          </div>
          <div class="clearfix"></div>
          <!-- menu prile quick info -->
          <!-- /menu prile quick info -->
          <br />
          <!-- sidebar menu -->
          <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
             <h4></h4>
              <ul class="nav side-menu">
                <li><a href="index.php?lat=<?php echo $_GET['lat'];?>&lon=<?php echo $_GET['lon'];?>"><i class="fa fa-book"></i>MyNews</a></li>
                <li><a id="date"><i class="fa fa-calendar"></i>Date Ranges</a></li>
                <li><a id="catlink"><i class="fa fa-calendar"></i>Category Based</a></li>
             </ul>    
            </div>
          </div>
          <!-- /sidebar menu -->

               
          <!-- /menu footer buttons -->
          <!-- /menu footer buttons -->
     </div>
 </div>