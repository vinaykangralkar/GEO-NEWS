Did you ever had the chance to experience all of the news happening in the whole world in a single page?

Location based news with sentimental analysis displayed on Google maps.

Explore it!!!

Support & Documentation

Visit https://feedtomap-coderpujan.c9users.io/index.html for experiencing News Feed in A completely different way

Have a Good Day !!
